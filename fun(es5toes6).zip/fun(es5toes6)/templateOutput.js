function Output() {
    this.output = "";
}


Output.prototype.addOutput = function (str) {
    this.output += str + " ";

};