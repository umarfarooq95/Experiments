var str = "function (event){" + "console.log(event)" + "}";


