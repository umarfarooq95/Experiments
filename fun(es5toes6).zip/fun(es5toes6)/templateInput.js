

var templateInputStr = "function (event,obj) { console.log(1+2) }" ;
